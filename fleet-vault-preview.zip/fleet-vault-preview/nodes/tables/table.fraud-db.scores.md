---
id: table.fraud-db.scores
node_type: table
title: scores
as_of: 2026-08-20
tags: [type/table, health/none]
database: fraud-db
schema: outputs
qualified_name: FRAUD_DB.OUTPUTS.SCORES
---

# scores

`FRAUD_DB.OUTPUTS.SCORES`

## Written by
- [fraud-scorer](../repos/repo.fraud-scorer.md) *(declared: codescan, verified)*

## Read by
*(none observed)*

Hub: [db.fraud-db](../../hubs/db.fraud-db.md)
