# mission — Command's Runbook

Step-by-step from zip to daily use. You do the ☐ steps; Claude Code does the
build work per START_HERE.md. Sessions are sized so any one fits in a sitting.

## Standing instruction to Claude (paste once, first session)

> Maintain `docs/BUILDLOG.md` as an append-only build log for this project.
> After every working session (and at every phase acceptance), append an
> entry using the template at the bottom of RUNBOOK.md: date, phase,
> what was built or changed, test count/status, any deviation from
> SPEC.md (explained), open questions for Command, and the next step.
> Never rewrite or delete prior entries. Commit the log with the work it
> describes. If a session ends abruptly, the log entry is the first thing
> the next session writes from git evidence.

## Session 0 — arrival (~30 min, mostly you)

(Literal copy-paste commands for this session: START_HERE_OPERATOR.md)

- ☐ Transfer `mission-project.zip` through your approved inbound channel; unzip to `~/mission-project`
- ☐ `cd ~/mission-project && git init && git add -A && git commit -m "baseline: design artifacts v0"`
- ☐ Shell alias in your rc: `alias mission="python3 ~/mission-project/mission-runtime/cli/mission.py"` → verify `mission help` prints the menu
- ☐ In a Claude Code session: run `/doctor` — record anything it flags in `docs/environment.md` (see note below)
- ☐ Tell Claude: "Read START_HERE.md and RUNBOOK.md. Adopt the standing build-log instruction. Do Phase 0." (Probes are mostly pre-answered — expect it to write `docs/environment.md` and commit)
- ☐ Add the CLI allow-list line to project settings (START_HERE probe 5) — verify a `mission status` call runs unprompted
- ☐ Seed `CLAUDE.md` (user or repo) with your standing directives (e.g. MCP usage for searches) and `crew.toml [commands]` with your real invocations (`pipenv run pytest …`)
- ☐ Acceptance: `docs/environment.md` exists, BUILDLOG has entry #1, two commits beyond baseline

## Session 1 — toy repo (Claude builds, you skim)

- ☐ "Do Phase 1." → `fixtures/toyrepo/` with the three seeded breakages
- ☐ You: 5 minutes reading the fixtures — they're your eval substrate; sanity matters
- ☐ Acceptance: each breakage reproduces on command; BUILDLOG entry; commit

## Sessions 2–3 — CLI extensions (Claude builds, you review diffs)

Priority order (tell Claude this order; it differs from START_HERE's listing):
1. crew.toml loading + enforcement of [limits]/[budgets]/[notifications]/[roster] (knobs are currently decorative)
2. Git checkpoint commits per step + `mission revert`
3. `mission resume` / `mission abort`
4. The wrap/acceptance runner (`mission accept`: re-run all DoD gates)
5. Consistency lint (`mission lint`): codex-referenced members exist, harness commands parse against argparse, doc-claimed commands exist, every knob has a reader, generated-code syntax checks
6. Packaging (`pyproject.toml` entrypoint → real `mission` command; drop the alias)
7. `crew lint/sync` group (fold in `crew-stats`), `harness --show`, cost tracking, amendment reconciliation, board polish
- ☐ You after each: review the diff, run `python3 -m pytest mission-runtime/cli -q`, approve the commit
- ☐ Acceptance: tests green (count grows), BUILDLOG entries per session

## Session 4 — first live mission (the milestone)

- ☐ Install: skill dir → `.claude/skills/mission/`; "run `mission crew sync`" (members → agents dir)
- ☐ In CC: `/mission fix the failing retry test in fixtures/toyrepo` → expect: fast path (one line, `y`), Medic summon banner, gate runs via [commands], board renders, wrap reports
- ☐ Watch for the audit-predicted seam bugs: member status calls parsing, actor attribution in `crew-stats`, scope fence, tool-allowlist ENFORCEMENT on a member (try to make Scout write a file — it must fail)
- ☐ Acceptance: one honest wrap; every hiccup goes in BUILDLOG verbatim — these are the most valuable bugs of the project
- ☐ Then one MEDIUM mission on the toyrepo flaky-fixture case: recon → plan doc → your inline `?>` comment answered → greenlight → checkpoint pause honored

## Session 5 — eval pass

- ☐ "Do Phase 4: run mission-evals.json as scripted scenarios; grade; write results to evals/results/; propose tunes, don't apply them"
- ☐ You: review proposals, approve tunes one at a time, re-run evals after each, commit
- ☐ Acceptance: calibration cases pass; every failure has a written proposal; BUILDLOG summarizes the tuning round

## Week 2 — dogfooding protocol

- ☐ Use `/mission` for every real task bigger than trivial; keep the scorecard (time-to-verified-done + interventions, vs your honest raw-CC estimate) in `docs/scorecard.md`
- ☐ Kill criteria, pre-committed: any task class where mission loses 3× goes back to raw CC (note it, don't force it)
- ☐ First campaign when ready: pilot one OAuth repo as a normal mission → summon Tactician → validate on repo #2 → fleet
- ☐ First `mission retro` after ~8 wraps: work the agenda (scorecard, gaps/hires, crew-stats, tunes)
- ☐ Only after retro #1 feels earned: the sponsorship conversation, with BUILDLOG + scorecard as your evidence

## Note on /doctor

Yes, run it — Session 0, before anything else. It's Claude Code's built-in
install/settings health check; on a managed enterprise setup it's the
fastest way to surface version, settings, or permission problems before
you'd otherwise discover them mid-Phase-3. Cheap, read-only, and its
output belongs in `docs/environment.md`. If it flags anything about
settings validity, resolve that before installing the skill.

## BUILDLOG entry template

```markdown
## 2026-MM-DD — Session N (Phase X)
**Built/changed:** …
**Tests:** N passing (was M)
**Deviations from spec:** none | <what + why>
**Found/fixed:** …
**Needs Command:** …
**Next:** …
```
