# Rotate creds — fraud-scorer

- [ ] rotate Snowflake service account password for [fraud-scorer](../nodes/repos/repo.fraud-scorer.md)
- context: still on password auth (see snowflake_auth in its properties)
