---
id: db.fraud-db
node_type: hub
hub_kind: db
title: fraud-db
as_of: 2026-08-20
tags: [type/hub]
members_count: 2
---

# Database: fraud-db

| Table | Writers | Readers |
|---|---|---|
| [txn_features](../nodes/tables/table.fraud-db.txn-features.md) | 1 | 2 |
| [scores](../nodes/tables/table.fraud-db.scores.md) | 1 | 0 |
