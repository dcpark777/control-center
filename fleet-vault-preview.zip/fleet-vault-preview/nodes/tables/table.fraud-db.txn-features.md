---
id: table.fraud-db.txn-features
node_type: table
title: txn_features
as_of: 2026-08-20
tags: [type/table, health/none]
database: fraud-db
schema: features
qualified_name: FRAUD_DB.FEATURES.TXN_FEATURES
---

# txn_features

`FRAUD_DB.FEATURES.TXN_FEATURES`

## Written by
- [feature-builder-kfp](../repos/repo.feature-builder-kfp.md) *(declared: codescan, verified)*

## Read by
- [fraud-scorer](../repos/repo.fraud-scorer.md) *(observed: ACCESS_HISTORY, 2026-08-19)*
- [txn-stream-rts](../repos/repo.txn-stream-rts.md) *(observed: ACCESS_HISTORY, 2026-08-19)*

Hub: [db.fraud-db](../../hubs/db.fraud-db.md)
