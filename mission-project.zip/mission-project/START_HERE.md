# START_HERE — build instructions for Claude Code

You are picking up **mission**: a mission-control framework for Claude Code.
The design phase is COMPLETE. Your job is implementation, faithful to the
documents in this repo. The human you are working with is **Command** (Dan);
defer every judgment call the spec doesn't settle to them.

ALSO: RUNBOOK.md is Command's step-by-step path and contains a standing
instruction you must adopt — maintain `docs/BUILDLOG.md` (append-only,
template at the bottom of RUNBOOK.md) after every session and phase
acceptance. Command's session ordering in RUNBOOK.md overrides the phase
listing below where they differ (notably the Phase 2 priority order).

## Read order (do this first, fully, before writing anything)

1. `SPEC.md` — the architecture and mechanics. It is authoritative.
2. `mission-skill/SKILL.md` — the Captain's judgment codex (§11 failure
   table especially).
3. `mission-runtime/harness.md` — the protocol wrapper contract.
4. `mission-runtime/crew.toml` — every tunable knob; nothing numeric is
   hardcoded anywhere.
5. `mission-runtime/evals/mission-evals.json` — the acceptance suite the
   Captain must eventually pass.

## Non-negotiable build rules

- **Deterministic core, AI at the edges.** The `mission` CLI is plain
  Python: parsing, state machine, events, checkpoints, rendering. No AI
  calls inside the CLI. No AI behavior in code, ever — all judgment lives
  in the markdown files.
- **One truth.** `mission.json` + `events.log` are the only runtime state.
  Every renderer reads them; nothing else holds state.
- **Harness and knobs load from disk** (`harness.md`, `crew.toml`) — never
  inline them. Tunability is a core requirement.
- **Spec wins.** Where the spec and your instinct differ, the spec wins.
  Where the spec is silent or ambiguous, STOP and ask Command — do not
  fill gaps with design of your own.
- **No v2 features.** Sequential execution only, board.html read-only,
  no daemon, no watchers, no parallel worktrees. The v1 cutline in
  SPEC.md §13 is a fence.
- Test-first for the CLI. Small commits with clear messages; git history
  is the audit trail.

## Phase plan (one phase per session is fine; finish a phase before starting the next)

**Phase 0 — environment verification (~30 min).**
Run every probe below; report results to Command as a table (probe /
result / implication) before writing any code. Statusline is already
known to be disallowed here — SPEC §14 Q2 is resolved; do not test it.

Probes, in order:
1. **Versions.** `claude --version` (need skills/commands unification —
   a 2025+ release); `python3 --version` (need >=3.11 for tomllib);
   `git --version` and `git worktree list` in a scratch repo (worktrees
   are the checkpoint/campaign substrate).
2. **Skills are permitted.** Create a trivial skill at
   `.claude/skills/probe/SKILL.md` (name: probe, one-line description,
   body: "reply PROBE-OK"). New session: does `/probe` appear and fire?
   Managed/enterprise settings can restrict user skills — if this fails,
   STOP and report; the whole delivery mechanism needs a rethink with
   Command.
3. **Subagent dispatch.** Drop a minimal agent at
   `.claude/agents/probe-agent.md` (frontmatter name/description/tools:
   Read; body: "reply AGENT-OK"). Ask the session to delegate to it.
   Verifies the Task/subagent path works under the Bedrock backend.
4. **Headless mode.** `claude -p 'reply exactly OK' ` — non-interactive
   invocation returns cleanly. Used by eval grading and any scripted
   checks; also confirm JSON output flag works if available.
5. **Settings precedence.** Confirm a project-level
   `.claude/settings.json` is honored (add a harmless setting) and note
   anything managed settings lock. Known already: git push and PR
   creation always require approval — mission's per-action approval
   design assumes this, so it's compatible, just record it.
6. **Notifications.** Probe the OS-notification path available to a CLI
   in this environment (and terminal bell as fallback). If none is
   permitted, record it: notify_on falls back to bell + board only.
7. **Model access + limits.** Which models are available via this CC
   install, and any rate/token constraints worth knowing before
   subagent-heavy missions. Record; do not tune around it yet.

Then `git init`, commit the bundle as-is: `baseline: design artifacts
v0`, followed by a second commit adding the probe results as
`docs/environment.md`.

**Phase 1 — toy fixture repo.**
Build `fixtures/toyrepo/`: a small Python project deliberately broken to
match the eval setups — a failing retry test with a changed default
timeout, a parallel-unsafe shared fixture behind flaky auth tests, a
misspelled gate path that makes pytest collect 0 tests. Acceptance: each
eval case's `setup` line has a matching reproducible state.

**Phase 2 — the `mission` CLI skeleton.**
A working core is ALREADY INCLUDED at `mission-runtime/cli/mission.py`
with its test suite (`test_mission.py` — run it for the current count; all green): dialect compiler,
state machine + events.log, gate runner with vacuous-check, redo with
critique + max_attempts, why, transcript board, and board.html with the
DAG SVG (artifact-labeled edges, anchor-jump nodes, auto-refresh).
Start by READING it and running its tests; then extend rather than
rewrite. Remaining to implement per SPEC §5–6: git checkpoint commits + `revert`; `init` (repo scan + intro) and
bare-`mission` where-was-I across missions; `resume`, `abort`,
`crew lint/sync` (and fold the existing flat `crew-stats` into that
`crew` subcommand group); cost/elapsed tracking into totals; amendment
compiles (plan v2+ diffs) AND reconciliation into live mission.json;
crew.toml LOADING — no knob is currently read by the CLI, so [budgets],
[limits], [notifications], [commands], and [roster] thresholds are
specced but UNENFORCED until wired; `mission harness --show` (spec §15 Q5); the wrap/acceptance runner
(re-run all DoD gates against final state, §9.6 — currently no command
executes the DoD at all); richer board styling per §8.2's visual grammar.
Acceptance: unit tests green; compiling the SPEC §6.1 example plan
round-trips correctly; a hand-driven fake mission (CLI calls only, no AI)
walks the full state machine cleanly.

**Phase 3 — wire the Captain.**
Install `mission-skill/` at `.claude/skills/mission/`, members via
`mission crew sync`. Run one real end-to-end mission on the toy repo
(the failing retry test — eval case `size-small-zero-questions`).
Acceptance: fast path fires, gate runs, checkpoint exists, board renders,
wrap reports honestly.

**Phase 4 — eval pass.**
Run the full eval suite as scripted scenarios; grade per case; record
results in `evals/results/`. Failures produce codex/harness/knob tuning
proposals for Command — never silent codex edits. Acceptance: calibration
cases pass; every failure has a written tuning proposal.

STOP after Phase 4. Real-repo dogfooding is Command's call, not yours.

## When you finish any phase

Summarize: what was built, what deviated from spec (should be nothing —
explain if not), what's ambiguous, what Command should decide next.
Keep it short and concrete.
