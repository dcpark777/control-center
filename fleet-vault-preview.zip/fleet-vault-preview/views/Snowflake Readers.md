---
id: view.snowflake-readers
title: "View: Snowflake Readers"
as_of: 2026-08-20
---

# Snowflake Readers *(as of 2026-08-20)*

Data edges only — taxonomy spokes excluded. 🔴 red 🟡 yellow 🟢 green.

```mermaid
graph LR
  classDef red fill:#c0392b,color:#fff
  classDef yellow fill:#d4a017,color:#fff
  classDef green fill:#1e8449,color:#fff
  FS[fraud-scorer]:::red -->|reads| TF[(txn_features)]
  TS[txn-stream-rts]:::green -->|reads| TF
  FB[feature-builder-kfp]:::yellow -->|writes| TF
  FS -->|writes| SC[(scores)]
```
