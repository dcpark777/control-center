---
id: cat.realtime
node_type: hub
hub_kind: cat
title: realtime
as_of: 2026-08-20
tags: [type/hub]
members_count: 1
---

# Category: realtime

| Repo | Team | Health | Crit | Build |
|---|---|---|---|---|
| [txn-stream-rts](../nodes/repos/repo.txn-stream-rts.md) | fraud-core | 🟢 | 0 | [jenkins](https://jenkins.example.internal/job/txn-stream-rts) |
