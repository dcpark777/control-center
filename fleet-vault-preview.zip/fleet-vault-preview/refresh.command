#!/bin/zsh
# Dashboard action: refresh the fleet. Linked from Home.md.
# Adjust COSMO_DIR on the work machine; chmod +x refresh.command once.
COSMO_DIR="${COSMO_DIR:-$HOME/work/cosmo-ai}"
cd "$COSMO_DIR" || exit 1
echo "→ cosmo refresh (full collect + emit)"
python3 -m cosmo refresh
echo "\n✓ done — press any key to close"; read -k1
