---
id: demo
title: Demo walkthrough
---

# 🎬 Demo sequence (~6 min)

Prep once: save a "Demo" workspace (Workspaces core plugin) — sidebars
collapsed, Home in main pane, graph in a second tab, this note on phone/side.

1. **Home** (30s) — chips: live fleet state. Charts: health, crit trend,
   campaign burndown. "Every morning starts here; all generated, nothing hand-made."
2. **Red repo** (60s) — click fraud-scorer from Needs Attention. Why-red
   callout → signals table → provenance line ("every fact says who claimed it
   and when"). Click Jenkins link: one hop to the build.
3. **Campaign** (60s) — the board: pinned members, exit criterion, daily log.
   "Fleet change as a tracked object, not a spreadsheet."
4. **Graph tour** (90s) — full graph 2 seconds ("the estate"), then bookmarks:
   Health Lens → Batch Fleet → click a table, local graph = who touches it.
   Never dwell on the full hairball; the story is filtering down.
5. **Live curation** (60s) — curation board: change a team cell. Terminal:
   `cosmo refresh --fast`. Watch Home + graph recolor. "Markdown in,
   compiled truth out — that's the whole system."
6. **Close** (30s) — README on GitHub render: "same files, shareable tier.
   And the monthly brief is generated from this too."
