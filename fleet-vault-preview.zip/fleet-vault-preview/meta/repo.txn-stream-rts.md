---
meta_for: repo.txn-stream-rts
override_category: realtime
purpose: "Realtime txn scoring service"
---
