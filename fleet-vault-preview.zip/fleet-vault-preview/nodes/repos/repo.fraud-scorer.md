---
id: repo.fraud-scorer
node_type: repo
title: fraud-scorer
aliases: [fraud-scorer]
as_of: 2026-08-20
tags: [type/repo, cat/batch, team/fraud-core, health/red, vuln/critical, dep/snowflake-connector-python/1-1, dep/pyspark/3-4-1]
category: batch
team: fraud-core
health: red
completeness: 0.85
vulns_critical: 3
python: "3.10"
pyspark: "3.4.1"
snowflake_auth: password
sql_templating: jinja-string
signals_stale: []
dep_snowflake_connector_python: "1.1"
dep_pyspark: "3.4.1"
deps:
  snowflake-connector-python: "1.1"
  pyspark: "3.4.1"
  pandas: "2.1.4"
jenkins: https://jenkins.example.internal/job/fraud-scorer
github: https://github.example.internal/fraud/fraud-scorer
---

# 🔴 fraud-scorer

**Batch scorer for transaction fraud** · team **fraud-core**
[GitHub](https://github.example.internal/fraud/fraud-scorer) · [Jenkins ▶](https://jenkins.example.internal/job/fraud-scorer) · [cat.batch](../../hubs/cat.batch.md) · [team.fraud-core](../../hubs/team.fraud-core.md)

> [!failure] Why red
> - **3 critical vulns** (Mend, 2026-08-20)
> - snowflake-connector-python **1.1** — fleet target is 3.6.0 → [campaign](../../meta/campaigns/campaign.connector-upgrade.md)

## Signals

| signal | value | as of | source |
|---|---:|---|---|
| vulns_critical | **3** | 08-20 | mend |
| base_image_age_days | 210 | 08-19 | dockerscan |
| build_status | passing | 08-20 | jenkins |

## Data flow

**Reads** ← [txn_features](../tables/table.fraud-db.txn-features.md) · observed (ACCESS_HISTORY 08-19)
**Writes** → [scores](../tables/table.fraud-db.scores.md) · declared, verified

**Depends** · [snowflake-connector-python](../packages/pkg.snowflake-connector-python.md) `1.1` · [pyspark] `3.4.1` · resolved via lockfile

## History

- `08-19` health 🟡→🔴 · vulns 1→3
- `08-10` connector pinned 1.1 (rollback)

> [!quote]- Label provenance
> `category: batch` — classified · rule `batch-default` · evaluated_sha `a1b2c3d`
> `team: fraud-core` — curated · 2026-08-20

📝 [1 open note](../../notes/rotate-creds-fraud-scorer.md)
