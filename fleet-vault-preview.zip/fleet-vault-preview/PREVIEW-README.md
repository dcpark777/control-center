# fleet-vault PREVIEW — what this is and what to do with it

A synthetic 3-repo fleet rendered EXACTLY per SPEC-ADDENDUM-A §2 — every node
type, all three health states, all four provenance sources (observed, declared,
curated incl. an override-with-drift, classified incl. evaluated_sha), a
campaign mid-flight, staleness flags, needs-curation queue, both dashboards.

## Tonight (personal machine)
Open this folder as an Obsidian vault (Open folder as vault). Then judge:
1. Home.md — is this the morning surface you want? What's missing/noisy?
2. A repo note (fraud-scorer) — properties panel + body order. Too much frontmatter?
3. Graph view — colors pre-seeded. Type filters from docs/USING.md step 3.
   Bookmark one. Toggle hubs on/off via `-tag:#type/hub` — do hub spokes help or clutter?
4. Home's embedded fleet.base — sortable/filterable table + cards, click
   the toolbar filter to feel the ad-hoc query experience (this is the
   zero-plugin "dynamic queries" answer)
5. The campaign note + package note — is the version-grouped layout right?
Also test (2 min): the ✏️ Curate button — edit a team cell in the base table,
then open the meta file to see the frontmatter change (this is bootstrap's UI).
And the ⟳ Refresh button — file:// link to refresh.command; if Obsidian won't
launch it directly on your version, drag refresh.command into the Dock or
Finder toolbar as the fallback (still one click, still visible output).

STYLE A/B: two skins, same structure. Ops (default): "cosmo" snippet + Home.md,
dark-leaning. Apple-style: enable "cosmo-soft" snippet, disable "cosmo" (Settings →
Appearance → CSS snippets), light mode, open Home-soft.md — SF system type,
Apple semantic colors, large rounded corners, hairline tables. Pick one; the loser's files just get
deleted from the reference. Style is an emit parameter in the end
(cluster (d): `emit --palette ops|soft` selects the chart set + snippet).

Write nitpicks directly into notes/ — they transfer with the folder.

## Tomorrow (work machine)
Transfer this folder into the cosmo repo as docs/vault-reference/ and tell
Claude Code, at cluster (c)/(d):
  "docs/vault-reference/ is the golden rendering target — match its file
   layout, frontmatter, body section order, link style, and .obsidian seeds
   exactly unless the addendum contradicts it (addendum wins). My taste
   notes are in its notes/ folder — apply them."
The .obsidian/graph.json color groups + app.json are the --init seed payload.
Bookmarks are deliberately NOT pre-seeded (app-managed file) — USING.md step 4
covers creating them, ~10s each.
