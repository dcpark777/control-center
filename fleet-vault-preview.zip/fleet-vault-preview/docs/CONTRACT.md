# CONTRACT — how to read this vault

**Generated** (do not edit): nodes/ hubs/ indexes/ views/ Home.md README.md and this file.
**Yours**: notes/ (anything), meta/ (frontmatter facts), meta/config/ (rules), templates/ (after seeding).

## Glossary
- **view** — a saved graph filter (an Obsidian bookmark)
- **campaign** — a pinned repo set with an exit criterion, tracked daily
- **watch** — a rule that flags changes on Home/README
- **meta** — a curated fact you supply (team, purpose, overrides)
- **note** — your freeform annotation; node links surface it on that node's page
- **hub** — a rollup page per category/team/database; also clusters the graph

## Trust marks
- every page header carries `as_of`; stale signals are flagged inline ⚠
- every fact names its source: observed / declared / curated / classified (+ rule + evaluated_sha)
- disagreements between sources are drift entries, never silently resolved

## Tags (the lens API)
type/* · cat/* · team/* · health/* · vuln/critical · campaign/* · dep/<pkg>/<version>

## Bases
`fleet.base` is emitted — its saved views regenerate on emit (your toolbar
tweaks to ad-hoc filters are fine; re-save custom views under a new name in
a base of your own if you want them to survive). Do NOT bulk-edit properties
of generated node files through base tables — edits land in generated
frontmatter and are clobbered next emit; curate via meta/ instead.
