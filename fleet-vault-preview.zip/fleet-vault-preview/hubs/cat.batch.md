---
id: cat.batch
node_type: hub
hub_kind: cat
title: batch
as_of: 2026-08-20
tags: [type/hub]
members_count: 1
---

# Category: batch

| Repo | Team | Health | Crit | Build |
|---|---|---|---|---|
| [fraud-scorer](../nodes/repos/repo.fraud-scorer.md) | fraud-core | 🔴 | 3 | [jenkins](https://jenkins.example.internal/job/fraud-scorer) |
