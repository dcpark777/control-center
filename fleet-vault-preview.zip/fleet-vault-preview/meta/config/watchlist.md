---
watchlist:
  - snowflake-connector-python
  - pyspark
---

# Package watchlist

Watchlist packages get: a node page, dep/<pkg>/<version> tags, and flat
dep_* frontmatter keys on repos. Everything else lives in the deps map only.
