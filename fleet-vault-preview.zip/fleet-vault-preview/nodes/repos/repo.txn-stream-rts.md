---
id: repo.txn-stream-rts
node_type: repo
title: txn-stream-rts
aliases: [txn-stream-rts]
as_of: 2026-08-20
tags: [type/repo, cat/realtime, team/fraud-core, health/green, dep/snowflake-connector-python/3-6-0]
category: realtime
team: fraud-core
health: green
completeness: 0.9
vulns_critical: 0
python: "3.11"
snowflake_auth: oauth
signals_stale: []
dep_snowflake_connector_python: "3.6.0"
deps:
  fastapi: "0.111.0"
  snowflake-connector-python: "3.6.0"
jenkins: https://jenkins.example.internal/job/txn-stream-rts
github: https://github.example.internal/fraud/txn-stream-rts
---

# txn-stream-rts 🟢

Realtime txn scoring service · **fraud-core** · [GitHub](https://github.example.internal/fraud/txn-stream-rts) · [Jenkins](https://jenkins.example.internal/job/txn-stream-rts)

## Signals
| signal | value | as_of | source |
|---|---|---|---|
| vulns_critical | 0 | 2026-08-20 | mend |
| build_status | passing | 2026-08-20 | jenkins |

`category: realtime` *(curated override; superseded: classified=batch · drift logged)*
`team: fraud-core` *(curated, 2026-08-20)*

## Reads
- [txn_features](../tables/table.fraud-db.txn-features.md) *(observed: ACCESS_HISTORY, 2026-08-19)*

## Depends on
- [snowflake-connector-python](../packages/pkg.snowflake-connector-python.md) `3.6.0` *(resolved: lockfile)*

Hub: [cat.realtime](../../hubs/cat.realtime.md) · [team.fraud-core](../../hubs/team.fraud-core.md)

## History
- 2026-08-20 · category batch→realtime (curated override)
