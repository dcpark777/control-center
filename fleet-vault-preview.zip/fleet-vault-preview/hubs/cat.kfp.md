---
id: cat.kfp
node_type: hub
hub_kind: cat
title: kfp
as_of: 2026-08-20
tags: [type/hub]
members_count: 1
---

# Category: kfp

| Repo | Team | Health | Crit | Build |
|---|---|---|---|---|
| [feature-builder-kfp](../nodes/repos/repo.feature-builder-kfp.md) | ml-platform | 🟡 | 0 | [jenkins](https://jenkins.example.internal/job/feature-builder-kfp) |
