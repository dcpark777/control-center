---
id: pkg.snowflake-connector-python
node_type: package
title: snowflake-connector-python
as_of: 2026-08-20
tags: [type/package]
versions_in_fleet: ["1.1", "3.6.0"]
repos_count: 2
fleet_target: "3.6.0"
---

# snowflake-connector-python

Fleet target: **3.6.0** *(curated)*

## Used by

### 3.6.0
- [txn-stream-rts](../repos/repo.txn-stream-rts.md)

### 1.1  ⚠ below target
- [fraud-scorer](../repos/repo.fraud-scorer.md)
