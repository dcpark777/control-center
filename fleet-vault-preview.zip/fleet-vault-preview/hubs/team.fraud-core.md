---
id: team.fraud-core
node_type: hub
hub_kind: team
title: fraud-core
as_of: 2026-08-20
tags: [type/hub]
members_count: 2
---

# Team: fraud-core

| Repo | Cat | Health | Crit | Build |
|---|---|---|---|---|
| [fraud-scorer](../nodes/repos/repo.fraud-scorer.md) | batch | 🔴 | 3 | [jenkins](https://jenkins.example.internal/job/fraud-scorer) |
| [txn-stream-rts](../nodes/repos/repo.txn-stream-rts.md) | realtime | 🟢 | 0 | [jenkins](https://jenkins.example.internal/job/txn-stream-rts) |
