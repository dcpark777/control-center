#!/usr/bin/env python3
"""mission — deterministic CLI core (v0, built per SPEC.md).

Stdlib-only by design (work env: Claude cannot install packages).
Subcommands: compile, init, status, done, gate, redo, why, board, render, log.
State lives ONLY in mission.json + events.log (Law 2). No AI anywhere (Law 1).
"""
import argparse, datetime, json, re, subprocess, sys
from pathlib import Path

STATES = ["queued", "active", "done", "paused-for-you", "failed", "redoing"]
GLYPH = {"queued": "○", "active": "▶", "done": "✓",
         "paused-for-you": "⏸", "failed": "✗", "redoing": "↻"}
LEGAL = {  # from -> allowed to
    "queued": {"active"},
    "active": {"done", "failed", "paused-for-you", "redoing"},
    "paused-for-you": {"active", "failed"},
    "failed": {"redoing", "paused-for-you"},
    "redoing": {"active"},
    "done": {"redoing", "done", "failed"},  # re-verification (gates/wrap) may confirm or demote
}
STEP_KEYS = {"scope", "needs", "done means", "gate", "artifact", "pause-after", "cast"}

SECRET_PATTERNS = [
    re.compile(r"AKIA[0-9A-Z]{16}"),                                  # AWS access key
    re.compile(r"gh[pousr]_[A-Za-z0-9]{20,}"),                        # GitHub tokens
    re.compile(r"(?i)bearer\s+[A-Za-z0-9._~+/=-]{16,}"),              # bearer tokens
    re.compile(r"(?i)(password|passwd|secret|token|api[_-]?key)(\s*[:=]\s*)(\S+)"),
]
def redact(text):
    if not text: return text
    for p in SECRET_PATTERNS[:3]: text = p.sub("[REDACTED]", text)
    text = SECRET_PATTERNS[3].sub(lambda m: m.group(1) + m.group(2) + "[REDACTED]", text)
    return text

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()

def die(msg, code=2):
    print(f"mission: {msg}", file=sys.stderr); sys.exit(code)

# ---------------- dialect parser / compiler ----------------

STEP_RE = re.compile(r"^##\s+Step\s+\d+\s+—\s+(?P<member>[\w-]+):\s*(?P<title>.*?)\s+\^(?P<id>[\w-]+)\s*$")
MISSION_RE = re.compile(r"^#\s+Mission:\s*(?P<title>.*?)\s+\^mission\s*$")
FIELD_RE = re.compile(r"^-\s+(?P<key>[a-z- ]+?):\s*(?P<val>.*)$")
DOD_RE = re.compile(r"^\s+-\s+\[(?P<kind>gate|human)\]\s*(?P<text>.*)$")
CMD_RE = re.compile(r"`(?P<cmd>[^`]+)`")

def parse_plan(text):
    """Parse the mission-plan.md dialect. Returns (plan_dict, problems:list)."""
    problems, mission, steps, cur = [], None, [], None
    for n, raw in enumerate(text.splitlines(), 1):
        line = raw.rstrip()
        m = MISSION_RE.match(line)
        if m:
            mission = {"title": m["title"], "goal": "", "dod": []}
            cur = ("mission", mission); continue
        m = STEP_RE.match(line)
        if m:
            step = {"id": m["id"], "member": m["member"].lower(), "title": m["title"],
                    "scope": "", "needs": [], "done_means": "", "gates": [],
                    "artifact": None, "pause_after": False, "max_attempts": 3}
            steps.append(step); cur = ("step", step); continue
        if cur and cur[0] == "mission":
            d = DOD_RE.match(line)
            if d:
                item = {"kind": d["kind"], "text": d["text"].strip()}
                c = CMD_RE.search(d["text"])
                if d["kind"] == "gate":
                    if c: item["cmd"] = c["cmd"]
                    else: problems.append(f"line {n}: [gate] DoD has no `command`")
                mission["dod"].append(item); continue
        f = FIELD_RE.match(line)
        if f and cur:
            key, val = f["key"].strip(), f["val"].strip()
            kind, obj = cur
            if kind == "mission":
                if key == "goal": obj["goal"] = val
                elif key == "done means": pass  # list follows
                else: problems.append(f"line {n}: unknown mission key '{key}' (warning)")
            else:
                if key not in STEP_KEYS:
                    problems.append(f"line {n}: unknown step key '{key}' (warning)"); continue
                if key == "scope": obj["scope"] = val
                elif key == "needs": obj["needs"] = [x.strip() for x in val.split(",") if x.strip()]
                elif key == "done means": obj["done_means"] = val
                elif key == "artifact": obj["artifact"] = val
                elif key == "pause-after": obj["pause_after"] = val.lower() in ("yes", "true")
                elif key == "cast": obj["member"] = val.lower()
                elif key == "gate":
                    c = CMD_RE.search(val)
                    if c: obj["gates"].append({"cmd": c["cmd"]})
                    else: problems.append(f"line {n}: gate has no `command`")
    if mission is None: problems.append("no '# Mission: ... ^mission' header found")
    if not steps: problems.append("plan has no steps")
    seen = set()
    for s_ in steps:
        if s_["id"] in seen: problems.append(f"duplicate step anchor '^{s_['id']}'")
        seen.add(s_["id"])
    ids = {s["id"] for s in steps}
    for s in steps:
        for need in s["needs"]:
            if need not in ids: problems.append(f"step {s['id']}: needs unknown step '{need}'")
        if not s["done_means"]: problems.append(f"step {s['id']}: missing 'done means'")
        if not s["gates"]: problems.append(f"step {s['id']}: no machine gate (warning: [human]-verified)")
    # cycle check (Kahn)
    if steps and not toposort(steps): problems.append("dependency cycle detected")
    plan = {"title": (mission or {}).get("title", ""), "goal": (mission or {}).get("goal", ""),
            "dod": (mission or {}).get("dod", []), "steps": steps}
    return plan, problems

def toposort(steps):
    """Kahn's; returns list of layers (each a list of step ids) or None on cycle."""
    ids = [s["id"] for s in steps]
    needs = {s["id"]: set(s["needs"]) for s in steps}
    layers, placed = [], set()
    while len(placed) < len(ids):
        layer = [i for i in ids if i not in placed and needs[i] <= placed]
        if not layer: return None
        layers.append(layer); placed |= set(layer)
    return layers

# ---------------- mission dirs / state ----------------

MEMBER_STYLE = {"scout": ("🔭", (8, 145, 178)), "medic": ("⛑️", (220, 38, 38)),
                "builder": ("🔨", (22, 163, 74)), "skeptic": ("🔎", (217, 119, 6)),
                "tactician": ("🗺️", (124, 58, 237)), "workshop": ("🧰", (15, 118, 110))}

def summon_banner(member, title, attempt):
    import os
    glyph, rgb = MEMBER_STYLE.get(member, ("▶", (55, 65, 81)))
    take = f" · take {attempt}" if attempt > 1 else ""
    text = f"{glyph} ━━ {member.upper()} summoned — {title}{take} ━━"
    if sys.stdout.isatty() and not os.environ.get("NO_COLOR"):
        r, g, b = rgb
        return f"\033[1m\033[38;2;{r};{g};{b}m{text}\033[0m"
    return text

def mdir(root, mid): return Path(root) / ".crew" / "missions" / mid

def load(p):
    with open(p) as f: return json.load(f)

def save(p, obj):
    tmp = Path(str(p) + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2)); tmp.replace(p)

def append_event(d, actor, step, frm, to, reason, evidence=None):
    ev = {"ts": now(), "actor": actor, "step": step, "from": frm, "to": to, "reason": reason}
    if evidence: ev["evidence"] = redact(evidence[-2000:])
    with open(d / "events.log", "a") as f: f.write(json.dumps(ev) + "\n")
    return ev

def cmd_compile(a):
    text = Path(a.plan).read_text()
    plan, problems = parse_plan(text)
    hard = [p for p in problems if "(warning" not in p]
    for p in problems: print(("WARN  " if p not in hard else "ERROR ") + p)
    if hard: die(f"compile failed: {len(hard)} error(s); no plan.json written")
    d = mdir(a.root, a.id); d.mkdir(parents=True, exist_ok=True)
    pj = d / "plan.json"
    version = (load(pj)["version"] + 1) if pj.exists() else 1
    plan.update({"mission_id": a.id, "version": version})
    save(pj, plan)
    print(f"compiled plan v{version}: {len(plan['steps'])} steps -> {pj}")

def cmd_init(a):
    d = mdir(a.root, a.id)
    if (d / "mission.json").exists():
        die(f"mission {a.id} already initialized — re-init would destroy live state. "
            "Amendment reconciliation is the designed path for plan changes (pending feature).")
    plan = load(d / "plan.json")
    st = {"mission_id": a.id, "plan_version": plan["version"], "state": "active",
          "active_step": None, "awaiting_human": None,
          "steps": {s["id"]: {"state": "queued", "attempts": 0, "artifact": None,
                              "note": "", "cost_usd": 0.0} for s in plan["steps"]},
          "totals": {"elapsed_s": 0, "cost_usd": 0.0, "tokens": 0}}
    save(d / "mission.json", st)
    append_event(d, "cli", None, None, "active", f"mission initialized from plan v{plan['version']}")
    print(f"mission {a.id} initialized ({len(st['steps'])} steps queued)")

def transition(d, step_id, to, actor, reason, evidence=None):
    st = load(d / "mission.json")
    if step_id not in st["steps"]: die(f"unknown step '{step_id}'")
    s = st["steps"][step_id]; frm = s["state"]
    if to not in LEGAL.get(frm, set()):
        die(f"illegal transition {frm} -> {to} for {step_id}")
    s["state"] = to; s["note"] = reason
    if to == "active":
        s["attempts"] += 1; st["active_step"] = step_id
        try:
            stp = next(x for x in load(d / "plan.json")["steps"] if x["id"] == step_id)
            print(summon_banner(stp["member"], stp["title"], s["attempts"]))
        except (StopIteration, FileNotFoundError):
            pass
    if to in ("paused-for-you", "failed"):
        st["awaiting_human"] = step_id; print("\a", end="")  # bell (env: os notifications blocked)
    if to == "done" and st.get("active_step") == step_id: st["active_step"] = None
    save(d / "mission.json", st)
    append_event(d, actor, step_id, frm, to, reason, evidence)
    return st

def cmd_status(a):
    d = mdir(a.root, a.id)
    if a.step is None:  # bare status = board
        print(render_board(d)); return
    to = {"active": "active", "blocked": "paused-for-you"}[a.to]
    transition(d, a.step, to, a.actor, a.note or "")
    print(render_board(d))

def cmd_done(a):
    d = mdir(a.root, a.id)
    st = transition(d, a.step, "done", a.actor, a.note or "done")
    if a.artifact:
        st["steps"][a.step]["artifact"] = a.artifact; save(d / "mission.json", st)
    print(render_board(d))

def cmd_redo(a):
    d = mdir(a.root, a.id)
    st = load(d / "mission.json")
    if a.step not in st["steps"]: die(f"unknown step '{a.step}'")
    att = st["steps"][a.step]["attempts"]
    maxa = load(d / "plan.json")["steps"]
    maxa = next(s.get("max_attempts", 3) for s in maxa if s["id"] == a.step)
    if att >= maxa: die(f"max_attempts ({maxa}) reached for {a.step}; renegotiate instead")
    transition(d, a.step, "redoing", a.actor, f"redo requested: {a.critique}")
    print(f"{a.step} -> redoing (critique recorded; attempt {att + 1}/{maxa} on next active)")

VACUOUS = [re.compile(r"collected 0 items"), re.compile(r"no tests ran", re.I)]

def cmd_gate(a):
    d = mdir(a.root, a.id)
    plan = load(d / "plan.json")
    step = next((s for s in plan["steps"] if s["id"] == a.step), None) or die(f"unknown step {a.step}")
    results, ok = [], True
    for g in step["gates"]:
        r = subprocess.run(g["cmd"], shell=True, capture_output=True, text=True, cwd=a.root)
        out = (r.stdout + r.stderr)[-1500:]
        vac = any(p.search(out) for p in VACUOUS)
        passed = (r.returncode == 0) and not vac
        ok &= passed
        results.append({"cmd": g["cmd"], "rc": r.returncode,
                        "vacuous": vac, "passed": passed, "tail": out.strip()[-400:]})
        print(f"gate {'PASS' if passed else ('VACUOUS' if vac else 'FAIL')}: {g['cmd']}")
    ev = json.dumps(results)[:1800]
    if ok: transition(d, a.step, "done", "gates", "all gates green", ev)
    else: transition(d, a.step, "failed", "gates",
                     "gate failed" + (" (vacuous pass detected)" if any(r["vacuous"] for r in results) else ""), ev)
    sys.exit(0 if ok else 1)

def gaps_path(a):
    d = Path(a.dir).expanduser() if a.dir else Path(a.root) / ".crew" / "learnings"
    d.mkdir(parents=True, exist_ok=True); return d / "gaps.jsonl"

def cmd_gap(a):
    p = gaps_path(a)
    ev = {"ts": now(), "capability": a.capability.strip().lower(),
          "mission": a.id, "step": a.step, "note": a.note or ""}
    with open(p, "a") as f: f.write(json.dumps(ev) + "\n")
    n = sum(1 for l in open(p) if json.loads(l)["capability"] == ev["capability"])
    print(f"gap recorded: '{ev['capability']}' (seen {n}x total)")
    if n >= a.threshold:
        print(f"HIRE SIGNAL: '{ev['capability']}' has {n} gaps (threshold {a.threshold}) — "
              f"propose a specialist to Command / route to Workshop")

def cmd_gaps(a):
    p = gaps_path(a)
    if not p.exists(): print("no gaps recorded"); return
    counts = {}
    for l in open(p):
        ev = json.loads(l); counts[ev["capability"]] = counts.get(ev["capability"], 0) + 1
    for cap, n in sorted(counts.items(), key=lambda x: -x[1]):
        flag = "  <- HIRE SIGNAL" if n >= a.threshold else ""
        print(f"{n:>3}x  {cap}{flag}")

def cmd_crew_stats(a):
    """Aggregate member behavior across all missions under root (events.log is truth)."""
    base = Path(a.root) / ".crew" / "missions"
    stats = {}
    for md in sorted(base.glob("*/")):
        pj, ev = md / "plan.json", md / "events.log"
        if not (pj.exists() and ev.exists()): continue
        member_of = {s["id"]: s["member"] for s in load(pj)["steps"]}
        for line in ev.read_text().splitlines():
            e = json.loads(line)
            m = member_of.get(e.get("step"))
            if not m: continue
            st = stats.setdefault(m, {"steps": set(), "activations": 0, "redos": 0,
                                      "gate_pass": 0, "gate_fail": 0, "violations": 0})
            st["steps"].add((md.name, e["step"]))
            if e["to"] == "active": st["activations"] += 1
            if e["to"] == "redoing": st["redos"] += 1
            if e["actor"] == "gates":
                st["gate_pass" if e["to"] == "done" else "gate_fail"] += 1
            if "scope" in e.get("reason", "").lower() and "violat" in e.get("reason", "").lower():
                st["violations"] += 1
    if not stats: print("no mission history under", base); return
    print(f"{'member':<10} {'steps':>5} {'takes/step':>10} {'gate 1st-try':>12} {'redos':>6} {'scope-viol':>10}")
    for m, s_ in sorted(stats.items()):
        n = len(s_["steps"]) or 1
        gates = s_["gate_pass"] + s_["gate_fail"]
        first = f"{s_['gate_pass']}/{gates}" if gates else "-"
        print(f"{m:<10} {len(s_['steps']):>5} {s_['activations']/n:>10.1f} {first:>12} {s_['redos']:>6} {s_['violations']:>10}")

MENU = """mission — mission control for Claude Code

  plan      compile <plan.md> --id X   validate the dialect -> plan.json (amendments re-version)
            init --id X                initialize live state from the compiled plan
  run       status --id X <step> active|blocked "note"   report/see state (harness form adds --actor)
            done --id X <step> "note" [--artifact F]     member reports work complete
            gate --id X <step>         run the step's gates: confirm or demote (vacuous-aware)
  steer     redo --id X <step> "critique"                revert intent + critique-carrying retry
            why --id X [step]          the evidenced event history behind any state
  inspect   (bare mission)             where-was-I brief across all missions
            board --id X               regenerate board.html (DAG + add-step palette)
            crew-stats                 per-member behavior across missions
            gaps [--dir D]             capability gaps + hire signals
  crew      gap "capability"           declare a casting gap (aggregates centrally)
            hire                       in a CC session: /mission hire a <specialist> — Workshop interviews you
                                       (hiring is a Captain action, not a CLI command; gaps feed it)

  coming    resume · abort · revert · crew lint/sync · harness --show · watch · accept (DoD run) · tour
"""

def cmd_home(a):
    base = Path(a.root) / ".crew" / "missions"
    briefs = []
    for md in sorted(base.glob("*/")) if base.exists() else []:
        mj = md / "mission.json"
        if not mj.exists(): continue
        st = load(mj)
        done = sum(1 for v in st["steps"].values() if v["state"] == "done")
        wait = f" ⏸ awaiting you: {st['awaiting_human']}" if st.get("awaiting_human") else ""
        briefs.append(f"  {st['mission_id']:<20} {done}/{len(st['steps'])} steps done · plan v{st['plan_version']}{wait}")
    if briefs:
        print("open missions:"); [print(b) for b in briefs]
        print()
        print("(`mission help` for all commands)")
    else:
        print(MENU)

def cmd_why(a):
    d = mdir(a.root, a.id)
    for line in (d / "events.log").read_text().splitlines():
        ev = json.loads(line)
        if a.step in (None, ev.get("step")):
            e = f"  evidence: {ev['evidence'][:200]}" if ev.get("evidence") else ""
            print(f"{ev['ts']}  {ev.get('step') or '-':>6}  {ev.get('from')}->{ev['to']}  [{ev['actor']}] {ev['reason']}{e}")

# ---------------- renderers ----------------

def render_board(d):
    plan, st = load(d / "plan.json"), load(d / "mission.json")
    lines = [f"mission {st['mission_id']} · plan v{st['plan_version']}"]
    for s in plan["steps"]:
        x = st["steps"][s["id"]]
        att = f" take {x['attempts']}/{s.get('max_attempts', 3)}" if x["attempts"] > 1 else ""
        art = f" → {x['artifact']}" if x["artifact"] else ""
        note = f" · {x['note']}" if x["note"] else ""
        pause = " ⏸-after" if s["pause_after"] else ""
        lines.append(f" {GLYPH[x['state']]} {s['member'].capitalize():<10} {s['title']:<28}{att}{art}{note}{pause}")
    if st.get("awaiting_human"): lines.append(f" ⏸ awaiting Command: {st['awaiting_human']}")
    return "\n".join(lines)

def dag_svg(plan, st):
    layers = toposort(plan["steps"]) or [[x["id"] for x in plan["steps"]]]
    color = {"queued": "#8a8f98", "active": "#2563eb", "done": "#15803d",
             "paused-for-you": "#b45309", "failed": "#b91c1c", "redoing": "#6d28d9"}
    W, H, BW, BH, X0 = 190, 96, 140, 50, 150
    pos = {}
    for li, layer in enumerate(layers):
        for ri, sid in enumerate(layer): pos[sid] = (X0 + li * W, 40 + ri * H)
    ax = X0 + len(layers) * W                      # acceptance column
    maxrows = max(len(l) for l in layers)
    width, height = ax + BW + 40, max(40 + maxrows * H + 30, 190)
    midy = height // 2 - BH // 2
    smap = {x["id"]: x for x in plan["steps"]}
    steps_done = all(v["state"] == "done" for v in st["steps"].values())
    el = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" font-family="ui-monospace,SFMono-Regular,Menlo,monospace" font-size="12">',
          '<defs><marker id="a" markerWidth="8" markerHeight="8" refX="7" refY="3" orient="auto"><path d="M0,0 L8,3 L0,6 z" fill="#8a8f98"/></marker></defs>']
    # source node: mission inputs
    el.append(f'<rect x="8" y="{midy}" width="118" height="{BH}" rx="3" fill="none" stroke="#8a8f98" stroke-dasharray="4 3"/>'
              f'<text x="16" y="{midy+20}" fill="#3f4650">inputs</text>'
              f'<text x="16" y="{midy+37}" fill="#8a8f98" font-size="10">{plan["title"][:16]}</text>')
    for sid in layers[0]:
        x2, y2 = pos[sid]
        el.append(f'<line x1="126" y1="{midy+BH//2}" x2="{x2}" y2="{y2+BH//2}" stroke="#8a8f98" marker-end="url(#a)"/>')
    # edges with artifact labels
    for x_ in plan["steps"]:
        for need in x_["needs"]:
            (x1, y1), (x2, y2) = pos[need], pos[x_["id"]]
            lbl = smap[need].get("artifact") or ""
            el.append(f'<line x1="{x1+BW}" y1="{y1+BH//2}" x2="{x2}" y2="{y2+BH//2}" stroke="#8a8f98" marker-end="url(#a)"/>')
            if lbl: el.append(f'<text x="{(x1+BW+x2)//2}" y="{(y1+y2)//2+BH//2-6}" fill="#6b7280" text-anchor="middle" font-size="10">{lbl}</text>')
    # sink edges -> acceptance
    sinks = [x["id"] for x in plan["steps"] if not any(x["id"] in o["needs"] for o in plan["steps"])]
    for sid in sinks:
        x1, y1 = pos[sid]
        el.append(f'<line x1="{x1+BW}" y1="{y1+BH//2}" x2="{ax}" y2="{midy+BH//2}" stroke="#8a8f98" marker-end="url(#a)"/>')
    # step nodes with badges
    for sid, (x, y) in pos.items():
        stp, live = smap[sid], st["steps"][sid]
        c = color[live["state"]]
        take = f' t{live["attempts"]}' if live["attempts"] > 1 else ""
        pause = " ⏸" if stp["pause_after"] else ""
        gates = " ⚑" * len(stp["gates"])
        el.append(f'<a href="#step-{sid}"><rect x="{x}" y="{y}" width="{BW}" height="{BH}" rx="3" fill="{c}14" stroke="{c}" stroke-width="1.5"/>'
                  f'<text x="{x+8}" y="{y+20}" fill="#1a1f26">{GLYPH[live["state"]]} {stp["member"]}{gates}{pause}{take}</text>'
                  f'<text x="{x+8}" y="{y+38}" fill="#3f4650" font-size="10">{stp["title"][:22]}</text>'
                  f'<title>{stp["scope"]} — done means: {stp["done_means"]}</title></a>')
    # acceptance node (DoD)
    ac = "#15803d" if steps_done else "#8a8f98"
    ng = sum(1 for x in plan["dod"] if x["kind"] == "gate"); nh = len(plan["dod"]) - ng
    el.append(f'<rect x="{ax}" y="{midy}" width="{BW}" height="{BH}" rx="3" fill="{ac}14" stroke="{ac}" stroke-width="2"/>'
              f'<text x="{ax+8}" y="{midy+20}" fill="#1a1f26">◎ done means</text>'
              f'<text x="{ax+8}" y="{midy+37}" fill="#3f4650" font-size="10">{ng} gates · {nh} human</text>'
              f'<title>Mission acceptance: all DoD criteria re-run at the wrap</title>')
    el.append("</svg>")
    return "".join(el)

DEFAULT_ROSTER = ["scout", "medic", "builder", "skeptic", "tactician", "workshop"]

def cmd_board(a):
    d = mdir(a.root, a.id)
    plan, st = load(d / "plan.json"), load(d / "mission.json")
    members = sorted({p.stem for p in (Path(a.root) / "crew").glob("*.md")} | set(DEFAULT_ROSTER))
    opts = "".join(f'<option>{m}</option>' for m in members)
    rows = ""
    for x in plan["steps"]:
        v = st["steps"][x["id"]]
        rows += (f'<section id="step-{x["id"]}"><h3>{GLYPH[v["state"]]} {x["id"]} — {x["member"]}: {x["title"]}</h3>'
                 f'<p><b>scope</b> {x["scope"]} · <b>done means</b> {x["done_means"]} · <b>state</b> {v["state"]}'
                 f' (take {v["attempts"]}){" · <b>note</b> " + v["note"] if v["note"] else ""}'
                 f'{" · <b>artifact</b> " + v["artifact"] if v["artifact"] else ""}</p></section>')
    palette = f"""<details id="palette"><summary>add step — generates a plan snippet; paste it into mission-plan.md among the "## Step" blocks, ABOVE the --- approve line, then recompile</summary>
<div class="form">
<label>cast <select id="pm">{opts}</select></label>
<label>title <input id="pt" placeholder="second recon pass"></label>
<label>scope <input id="ps" placeholder="tests/auth only"></label>
<label>needs <input id="pn" placeholder="s1, s2"></label>
<label>done means <input id="pd" placeholder="brief updated"></label>
<label>gate <input id="pg" placeholder="pipenv run pytest -q (optional)"></label>
<button onclick="gen()">Generate snippet</button> <span id="note" class="tot"></span>
<pre id="out"></pre></div>
<script>
function gen() {{
  const v = i => document.getElementById(i).value.trim();
  const NL = String.fromCharCode(10), BT = String.fromCharCode(96);
  const n = {len(plan["steps"]) + 1};
  const cast = v('pm').charAt(0).toUpperCase() + v('pm').slice(1);
  let sn = '## Step ' + n + ' — ' + cast + ': ' + v('pt') + '   ^s' + n + NL;
  if (v('pn')) sn += '- needs: ' + v('pn') + NL;
  sn += '- scope: ' + v('ps') + NL + '- done means: ' + v('pd') + NL;
  if (v('pg')) sn += '- gate: ' + BT + v('pg') + BT + NL;
  document.getElementById('out').textContent = sn;
  const note = document.getElementById('note');
  if (navigator.clipboard && navigator.clipboard.writeText) {{
    navigator.clipboard.writeText(sn).then(
      () => {{ note.textContent = 'copied to clipboard'; }},
      () => {{ note.textContent = 'clipboard unavailable here — select and copy from the box'; }});
  }} else {{ note.textContent = 'select and copy from the box'; }}
}}
</script></details>"""
    html = f"""<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="5">
<title>mission {st["mission_id"]}</title><style>
body {{font-family: ui-monospace, SFMono-Regular, Menlo, monospace; max-width: 900px;
      margin: 2rem auto; color: #1a1f26; background: #fbfbf9; padding: 0 1rem}}
h1 {{font-size: 1.15rem; letter-spacing: .02em}} h1 span {{color: #8a8f98; font-weight: normal}}
h3 {{font-size: .95rem; margin-bottom: .2rem}}
p, summary, label {{font-size: .82rem; color: #3f4650}}
section {{border-top: 1px solid #e4e2da; padding: .5rem 0}}
details {{margin: 1rem 0; border: 1px dashed #8a8f98; padding: .5rem; border-radius: 3px}}
.form label {{display: block; margin: .3rem 0}} .form input, .form select {{font: inherit; width: 60%}}
button {{font: inherit; margin-top: .4rem}} pre {{background: #f1efe9; padding: .5rem; white-space: pre-wrap}}
.tot {{color: #8a8f98; font-size: .8rem}}
</style><body>
<h1>⛑ {plan["title"]} <span>· plan v{plan["version"]} · {st["state"]}</span></h1>
<p>{plan["goal"]}</p>
{dag_svg(plan, st)}
<p class="tot">totals: ${st["totals"]["cost_usd"]:.2f} · {st["totals"]["elapsed_s"]}s{" · ⏸ awaiting Command: " + st["awaiting_human"] if st.get("awaiting_human") else ""}</p>
{palette}{rows}</body>"""
    out = d / "board.html"; out.write_text(html)
    print(f"board -> {out}")

def main(argv=None):
    ap = argparse.ArgumentParser(prog="mission")
    ap.add_argument("--root", default=".", help="repo root (default: cwd)")
    sub = ap.add_subparsers(dest="cmd", required=False)
    sub.add_parser("help").set_defaults(f=lambda a: print(MENU))
    c = sub.add_parser("compile"); c.add_argument("plan"); c.add_argument("--id", required=True); c.set_defaults(f=cmd_compile)
    c = sub.add_parser("init"); c.add_argument("--id", required=True); c.set_defaults(f=cmd_init)
    c = sub.add_parser("status"); c.add_argument("--id", required=True); c.add_argument("step", nargs="?")
    c.add_argument("to", nargs="?", choices=["active", "blocked"]); c.add_argument("note", nargs="?")
    c.add_argument("--actor", default="cli"); c.set_defaults(f=cmd_status)
    c = sub.add_parser("done"); c.add_argument("--id", required=True); c.add_argument("step"); c.add_argument("note", nargs="?")
    c.add_argument("--artifact"); c.add_argument("--actor", default="cli"); c.set_defaults(f=cmd_done)
    c = sub.add_parser("gate"); c.add_argument("--id", required=True); c.add_argument("step"); c.set_defaults(f=cmd_gate)
    c = sub.add_parser("redo"); c.add_argument("--id", required=True); c.add_argument("step"); c.add_argument("critique")
    c.add_argument("--actor", default="command"); c.set_defaults(f=cmd_redo)
    c = sub.add_parser("gap"); c.add_argument("capability"); c.add_argument("--id", default="-")
    c.add_argument("--step"); c.add_argument("--note"); c.add_argument("--dir")
    c.add_argument("--threshold", type=int, default=3); c.set_defaults(f=cmd_gap)
    c = sub.add_parser("gaps"); c.add_argument("--dir"); c.add_argument("--threshold", type=int, default=3)
    c.set_defaults(f=cmd_gaps)
    c = sub.add_parser("crew-stats"); c.set_defaults(f=cmd_crew_stats)
    c = sub.add_parser("why"); c.add_argument("--id", required=True); c.add_argument("step", nargs="?"); c.set_defaults(f=cmd_why)
    c = sub.add_parser("board"); c.add_argument("--id", required=True); c.set_defaults(f=cmd_board)
    a = ap.parse_args(argv)
    if a.cmd is None: a.f = cmd_home
    a.f(a)

if __name__ == "__main__":
    main()
