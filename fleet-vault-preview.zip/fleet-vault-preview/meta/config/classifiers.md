---
classifiers:
  category:
    values: [kfp, realtime, batch]
    rules:
      - id: kfp-1
        value: kfp
        when:
          any:
            - dep_exists: kfp
            - file_glob: "pipeline*.py"
      - id: rts-1
        value: realtime
        when:
          any:
            - name_matches: "-rts-"
            - dep_exists: fastapi
      - id: batch-default
        value: batch
        when: default
---

# Classifier rules

PREVIEW PLACEHOLDER — replace rules with your real heuristics at bootstrap.
Predicates: any/all/not · dep_exists · dep_version_cmp · file_glob ·
content_regex ({glob, pattern}) · signal_cmp · name_matches.
Validate cheaply: `cosmo refresh --fast`, then review the vault git diff.
Debug: `cosmo classify <id>` (explain is the default output).
