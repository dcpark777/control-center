# mission — User Guide

Mission control for Claude Code: summon a crew of named agents onto a task,
negotiate the plan in a document, watch execution on a live board, steer at
any moment. You are **Command**. The orchestrating agent is the **Captain**.
Nothing executes without your greenlight; nothing external happens without
your approval.

⏳ marks features that are specced but not yet built (see START_HERE.md).

## The two entrypoints

| You type | Where | What it is |
|---|---|---|
| `/mission <task>` | inside a Claude Code session | the **skill** — puts the Captain in your conversation: interviews, plans, casts, dispatches |
| `mission <cmd>` | any terminal | the **CLI** — deterministic state: compile, status, gates, board. The Captain and members call it too |

`mission help` prints the command menu. Bare `mission` shows your
where-was-I brief (or the menu if you have no missions).

## Quickstart — your first mission

```
/mission fix the failing retry test in tests/client
```
Small task → fast path: the Captain proposes a one-line plan with a gate,
you answer `y`, work happens in a worktree, the gate runs, you review the
diff, done. Total overhead over raw CC: one line and one keystroke.

For bigger tasks the Captain interviews you briefly (≤4 questions, each
one must change the plan), runs Scout recon so the plan is grounded in
your actual code, and writes `mission-plan.md` for you to negotiate.

## The lifecycle, and what you do at each stage

**Brief** — describe the task; answer at most a few questions, or accept
proposed defaults with one word.
**Plan** — read `mission-plan.md` in any editor. Edit anything directly
(edits are commands — the Captain obeys). Ask questions inline with `?>`
(comments are conversation — it answers beneath). Large plans get a
Skeptic review first, advisory findings above the approve box.
**Greenlight** — tick `[ ] Approve plan and launch` (or say `y`). The
plan freezes; execution follows it and nothing else.
**Execute** — watch the transcript board in your session, or open
`board.html` (auto-refreshes; shows the DAG). You'll be summoned (bell +
⏸) only when something is blocked on you.
**Wrap** — gates re-run against the definition of done ⏳; results and
learnings recorded; you review, approve any push (always per-action).

## Steering (any time)

| Gesture | How |
|---|---|
| Pause | say "pause" to the Captain — takes effect at the next tool boundary, nothing lost |
| Reject a step | `mission redo --id X s2 "critique"` or tell the Captain — reverts to checkpoint, retries WITH your critique |
| Edit code yourself | just do it — detected at the next dispatch, committed as "human edit", briefed to subsequent members |
| Edit the plan | edit the file, save; queued steps obey; done steps prompt "redo under new criteria?" |
| Ask why | `mission why --id X [step]` — evidenced event history behind any state |
| Add a step | board's "add step" palette generates the snippet → paste above the `---` approve line → recompile |

Every loop is bounded (attempts per step, redos per mission ⏳, cost and
time budgets ⏳). A mission can never grind unbounded — it pauses and asks.

## The plan file in 20 seconds

```markdown
# Mission: <title>            ^mission
- goal: <one line>
- done means:
  - [gate] `command that proves it`
  - [human] judgment criteria

## Step 1 — Scout: recon      ^s1
- scope: <the fence>
- done means: <one line>
- gate: `pipenv run pytest -q`   # optional per step
- needs: s0                       # dependencies = the DAG
- pause-after: yes                # declared review point
```
Anchors (`^s1`) are identity; file order is cosmetic — `needs` decides
execution. `[gate]` lines are commands; `[human]` lines are yours to judge.

## The crew

| Member | Job | Reaches for it when |
|---|---|---|
| 🔭 Scout | read-only recon, ranked brief | unfamiliar territory, grounding a plan |
| ⛑️ Medic | diagnose + minimal fix | something is broken, there's a log/traceback |
| 🔨 Builder | implement planned changes | migrations, upgrades, features, config |
| 🔎 Skeptic | adversarial review | a diff (or a LARGE plan) needs challenging |
| 🗺️ Tactician | pilot → fleet recipe | campaigns across many repos |
| 🧰 Workshop | makes new members | you say `/mission hire a <specialist>` |

**Hiring:** `/mission hire a jenkins log forensics specialist` → Workshop
interviews you (≤5 questions) → drafts `crew/<name>.md` → you review,
lint ⏳, git-commit = approval. The system also detects gaps itself:
`mission gaps` shows capabilities the Captain lacked, with a HIRE SIGNAL
at threshold. **Tuning:** members are plain markdown — edit them anytime
(never through the Captain; changes apply at the member's next dispatch).
**Accountability:** `mission crew-stats` — per-member takes, gate
first-try rate, redos, scope violations, across all missions.

## Fleet campaigns (many repos)

Pilot one repo as a normal mission → Tactician writes a parameterized
recipe with deterministic preflight checks → repo #2 validates it →
the rest run as fast-path missions; all external actions (PRs, pushes)
batch into one review sweep. ⏳ campaign runner; the pattern works
manually today (recipe = a plan you reuse).

## Where knowledge lives

| Kind | Home |
|---|---|
| secrets | keychain/env/token scripts — NEVER mission files |
| canonical invocations ("tests run via…") | `crew.toml [commands]` |
| standing directives ("use github MCP for search") | `CLAUDE.md` (user/repo) |
| mission-specific defaults | `captain-prefs.md` ⏳ |
| lessons + procedures discovered mid-mission | learnings store (`~/.crew/learnings/`, Obsidian-compatible) — written at wrap, read at every intake |

## When things go wrong

Gate keeps failing → after 2 identical failures the Captain stops early
and presents options. Mission too big mid-flight → renegotiation pause:
expand / split / abort. Session died → `mission resume` ⏳ rebuilds from
files. Wrong turn → `mission revert <step>` ⏳ / `git revert` (every step
is a checkpoint commit ⏳). Anything confusing → `mission why`.

## Command reference

`mission` where-was-I · `help` menu · `compile plan.md --id X` ·
`init --id X` · `status --id X [step active|blocked "note"]` ·
`done --id X step "note" [--artifact F]` · `gate --id X step` ·
`redo --id X step "critique"` · `why --id X [step]` · `board --id X` ·
`gap "capability"` · `gaps` · `crew-stats` ·
⏳ `resume · abort · revert · crew lint/sync · harness --show · watch · accept · tour`
