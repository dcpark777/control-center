"""Tests for mission.py — run: python3 -m pytest test_mission.py -q
Covers: dialect compile of the SPEC §6.1 example, hand-driven state-machine walk
(no AI, per START_HERE Phase 2 acceptance), gates incl. the vacuous check,
redo + max_attempts, illegal transitions, event log integrity, board render.
"""
import json, subprocess, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import mission as M

SPEC_PLAN = """# Mission: fix flaky auth tests            ^mission
- goal: auth test suite passes reliably in CI
- done means:
  - [gate] `pytest tests/auth -x -q` green 5x consecutively
  - [human] Dan agrees flake root cause is explained in the wrap

## Step 1 — Scout: recon                   ^s1
- scope: tests/auth/, conftest.py
- done means: written brief of suspected causes, ranked
- artifact: recon-brief.md

## Step 2 — Medic: fix                     ^s2
- needs: s1
- scope: minimal change to eliminate top-ranked cause
- done means: tests green
- gate: `true`

## Step 3 — Skeptic: adversarial review    ^s3
- needs: s2
- scope: the step-2 diff
- done means: no critical findings
- pause-after: yes

---
- [ ] **Approve plan and launch**          ^approve
"""

def mk(tmp_path, plan_text=SPEC_PLAN, mid="t1"):
    p = tmp_path / "plan.md"; p.write_text(plan_text)
    M.main(["--root", str(tmp_path), "compile", str(p), "--id", mid])
    M.main(["--root", str(tmp_path), "init", "--id", mid])
    return M.mdir(tmp_path, mid)

def test_compile_spec_example(tmp_path):
    d = mk(tmp_path)
    plan = json.load(open(d / "plan.json"))
    assert plan["version"] == 1 and plan["goal"].startswith("auth test suite")
    assert [s["id"] for s in plan["steps"]] == ["s1", "s2", "s3"]
    assert plan["steps"][1]["needs"] == ["s1"] and plan["steps"][1]["gates"][0]["cmd"] == "true"
    assert plan["steps"][2]["pause_after"] is True
    assert plan["dod"][0]["kind"] == "gate" and "pytest" in plan["dod"][0]["cmd"]
    assert plan["dod"][1]["kind"] == "human"

def test_compile_rejects_bad_needs(tmp_path):
    bad = SPEC_PLAN.replace("- needs: s1", "- needs: s9")
    p = tmp_path / "p.md"; p.write_text(bad)
    try:
        M.main(["--root", str(tmp_path), "compile", str(p), "--id", "x"])
        assert False, "should have exited"
    except SystemExit as e:
        assert e.code == 2
    assert not (M.mdir(tmp_path, "x") / "plan.json").exists()

def test_full_state_walk_and_events(tmp_path, capsys):
    d = mk(tmp_path)
    r = str(tmp_path)
    M.main(["--root", r, "status", "--id", "t1", "s1", "active", "scouting"])
    M.main(["--root", r, "done", "--id", "t1", "s1", "brief written", "--artifact", "recon-brief.md"])
    M.main(["--root", r, "status", "--id", "t1", "s2", "active", "fixing"])
    try: M.main(["--root", r, "gate", "--id", "t1", "s2"])
    except SystemExit as e: assert e.code == 0
    st = json.load(open(d / "mission.json"))
    assert st["steps"]["s1"]["state"] == "done" and st["steps"]["s1"]["artifact"] == "recon-brief.md"
    assert st["steps"]["s2"]["state"] == "done"
    evs = [json.loads(l) for l in (d / "events.log").read_text().splitlines()]
    assert evs[-1]["actor"] == "gates" and evs[-1]["to"] == "done"
    assert all(set(e) >= {"ts", "actor", "to", "reason"} for e in evs)

def test_illegal_transition_rejected(tmp_path):
    mk(tmp_path)
    try:
        M.main(["--root", str(tmp_path), "done", "--id", "t1", "s1", "nope"])  # queued -> done
        assert False
    except SystemExit as e:
        assert e.code == 2

def test_gate_failure_and_vacuous(tmp_path):
    plan = SPEC_PLAN.replace("- gate: `true`", "- gate: `echo 'collected 0 items'; exit 0`")
    d = mk(tmp_path, plan, "t2")
    r = str(tmp_path)
    M.main(["--root", r, "status", "--id", "t2", "s2", "active", "fixing"])
    try: M.main(["--root", r, "gate", "--id", "t2", "s2"])
    except SystemExit as e: assert e.code == 1
    st = json.load(open(d / "mission.json"))
    assert st["steps"]["s2"]["state"] == "failed"
    last = json.loads((d / "events.log").read_text().splitlines()[-1])
    assert "vacuous" in last["reason"] and last.get("evidence")

def test_redo_critique_and_max_attempts(tmp_path):
    d = mk(tmp_path, mid="t3")
    r = str(tmp_path)
    for i in range(3):
        M.main(["--root", r, "status", "--id", "t3", "s1", "active", f"attempt {i+1}"])
        if i < 2: M.main(["--root", r, "redo", "--id", "t3", "s1", "missed the async callers"])
    st = json.load(open(d / "mission.json"))
    assert st["steps"]["s1"]["attempts"] == 3
    try:
        M.main(["--root", r, "redo", "--id", "t3", "s1", "again"])
        assert False, "max_attempts should block"
    except SystemExit as e:
        assert e.code == 2
    evs = (d / "events.log").read_text()
    assert "missed the async callers" in evs  # critique is recorded verbatim

def test_board_and_dag_render(tmp_path, capsys):
    d = mk(tmp_path, mid="t4")
    out = M.render_board(d)
    assert "Scout" in out and "○" in out and "⏸-after" in out
    M.main(["--root", str(tmp_path), "board", "--id", "t4"])
    html = (d / "board.html").read_text()
    assert "<svg" in html and "recon-brief.md" in html  # artifact-labeled edge
    assert 'href="#step-s2"' in html                     # anchor-jump interaction
    assert "refresh" in html                             # auto-refresh meta
    assert ">inputs</text>" in html                      # source node present
    assert "◎ done means" in html                        # DoD acceptance node
    assert "add step" in html and "Generate snippet" in html     # rung-1 palette

def test_gap_ledger_and_hire_signal(tmp_path, capsys):
    d = str(tmp_path)
    for i in range(3):
        M.main(["gap", "pyspark pipeline surgery", "--dir", d, "--id", f"m{i}"])
    out = capsys.readouterr().out
    assert "seen 3x" in out and "HIRE SIGNAL" in out
    M.main(["gaps", "--dir", d])
    out = capsys.readouterr().out
    assert "3x  pyspark pipeline surgery  <- HIRE SIGNAL" in out

def test_crew_stats_aggregates_across_missions(tmp_path, capsys):
    for mid in ("a1", "a2"):
        mk(tmp_path, mid=mid)
        r = str(tmp_path)
        M.main(["--root", r, "status", "--id", mid, "s2", "active", "building"])
        try: M.main(["--root", r, "gate", "--id", mid, "s2"])
        except SystemExit: pass
    capsys.readouterr()
    M.main(["--root", str(tmp_path), "crew-stats"])
    out = capsys.readouterr().out
    assert "medic" in out and "2/2" in out  # two missions, both gates first-try

def test_evidence_redaction(tmp_path):
    d = mk(tmp_path, mid="t9")
    leaky = "conn failed: password=hunter2 token: abc123XYZ AKIAABCDEFGHIJKLMNOP ghp_aaaaaaaaaaaaaaaaaaaaaa"
    M.append_event(d, "test", "s1", "queued", "active", "leak test", leaky)
    last = json.loads((d / "events.log").read_text().splitlines()[-1])
    ev = last["evidence"]
    assert "hunter2" not in ev and "AKIAABCDEFGHIJKLMNOP" not in ev
    assert "ghp_aaaa" not in ev and "[REDACTED]" in ev

def test_member_done_then_gate_reverifies(tmp_path):
    """Harness flow: member reports done -> Captain runs gates -> confirm or demote."""
    plan = SPEC_PLAN.replace("- gate: `true`", "- gate: `false`")
    d = mk(tmp_path, plan, "t10")
    r = str(tmp_path)
    M.main(["--root", r, "status", "--id", "t10", "s2", "active", "building"])
    M.main(["--root", r, "done", "--id", "t10", "s2", "work complete", "--actor", "medic"])
    try: M.main(["--root", r, "gate", "--id", "t10", "s2"])
    except SystemExit as e: assert e.code == 1
    st = json.load(open(d / "mission.json"))
    assert st["steps"]["s2"]["state"] == "failed"  # gates demoted the member's claim

def test_reinit_refuses_to_destroy_state(tmp_path):
    mk(tmp_path, mid="t11")
    r = str(tmp_path)
    M.main(["--root", r, "status", "--id", "t11", "s1", "active", "working"])
    try:
        M.main(["--root", r, "init", "--id", "t11"])
        assert False, "re-init must refuse"
    except SystemExit as e:
        assert e.code == 2
    st = json.load(open(M.mdir(tmp_path, "t11") / "mission.json"))
    assert st["steps"]["s1"]["state"] == "active"  # state survived

def test_compile_rejects_duplicate_anchors_and_empty(tmp_path):
    dup = SPEC_PLAN.replace("^s3", "^s1")  # step 3 reuses step 1's anchor
    p = tmp_path / "dup.md"; p.write_text(dup)
    try:
        M.main(["--root", str(tmp_path), "compile", str(p), "--id", "d1"]); assert False
    except SystemExit as e: assert e.code == 2
    p2 = tmp_path / "empty.md"; p2.write_text("# Mission: t ^mission\n- goal: g\n")
    try:
        M.main(["--root", str(tmp_path), "compile", str(p2), "--id", "d2"]); assert False
    except SystemExit as e: assert e.code == 2

def test_bare_mission_menu_and_brief(tmp_path, capsys):
    M.main(["--root", str(tmp_path)])                     # no missions -> menu
    assert "mission control for Claude Code" in capsys.readouterr().out
    mk(tmp_path, mid="t12")
    M.main(["--root", str(tmp_path), "status", "--id", "t12", "s1", "active", "working"])
    M.main(["--root", str(tmp_path), "status", "--id", "t12", "s1", "blocked", "need you"])
    capsys.readouterr()
    M.main(["--root", str(tmp_path)])                     # missions exist -> brief
    out = capsys.readouterr().out
    assert "open missions:" in out and "t12" in out and "awaiting you: s1" in out
    M.main(["--root", str(tmp_path), "help"])
    assert "steer" in capsys.readouterr().out

def test_summon_banner_on_activation(tmp_path, capsys):
    mk(tmp_path, mid="t13")
    M.main(["--root", str(tmp_path), "status", "--id", "t13", "s1", "active", "scouting", "--actor", "scout"])
    out = capsys.readouterr().out
    assert "SCOUT summoned — recon" in out
    M.main(["--root", str(tmp_path), "redo", "--id", "t13", "s1", "again"])
    M.main(["--root", str(tmp_path), "status", "--id", "t13", "s1", "active", "take 2", "--actor", "scout"])
    assert "take 2 ━━" in capsys.readouterr().out
