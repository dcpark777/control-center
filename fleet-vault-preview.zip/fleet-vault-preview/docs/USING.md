# Using this vault

1. Install Obsidian → Open folder as vault → this folder.
2. Pin Home.md as your first tab. Optional but recommended: Settings → Appearance → install the "Minimal" theme (pure CSS, no code). The cosmo.css snippet is pre-enabled.
3. Graph view: colors are pre-seeded (red/yellow/green by health, purple hubs).
   Try filters: `tag:#cat/batch` · `tag:#dep/snowflake-connector-python/1-1` · `path:nodes/repos`
4. Save views: set a filter → Bookmark the graph → name it ("Health Lens",
   "Critical Vulns", "Campaign: connector-upgrade"). ~10s each, yours forever.
5. Right sidebar → Backlinks: open any repo note and see its daily-note
   mentions = its change timeline.
6. Curate: copy templates/meta.md into meta/<node-id>.md, fill frontmatter,
   run `cosmo refresh --fast`.
