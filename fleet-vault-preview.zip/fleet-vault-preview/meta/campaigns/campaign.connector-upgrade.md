---
id: campaign.connector-upgrade
node_type: campaign
status: active
created: 2026-08-15
rule: "deps[snowflake-connector-python] < 4.0"
target: "deps[snowflake-connector-python] > 3.5"
members: [repo.fraud-scorer, repo.txn-stream-rts]
---

# 🎯 connector-upgrade

> [!info] Progress — **1 / 2** `▃▄▅` · started 08-15 · target: connector **> 3.5**

| member | current | status |
|---|---:|---|
| [txn-stream-rts](../../nodes/repos/repo.txn-stream-rts.md) | 3.6.0 | ✅ 08-18 |
| [fraud-scorer](../../nodes/repos/repo.fraud-scorer.md) | **1.1** | ⏳ pending |

## Log

- `08-18` txn-stream-rts 1.1→3.6.0 ✅ *(1/2)*
- `08-15` created · 2 members pinned from rule
