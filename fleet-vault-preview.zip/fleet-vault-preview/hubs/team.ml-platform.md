---
id: team.ml-platform
node_type: hub
hub_kind: team
title: ml-platform
as_of: 2026-08-20
tags: [type/hub]
members_count: 1
---

# Team: ml-platform

| Repo | Cat | Health | Crit | Build |
|---|---|---|---|---|
| [feature-builder-kfp](../nodes/repos/repo.feature-builder-kfp.md) | kfp | 🟡 | 0 | [jenkins](https://jenkins.example.internal/job/feature-builder-kfp) |
