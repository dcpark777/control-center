---
id: home
title: Fleet Command
as_of: 2026-08-20
cssclasses: [dashboard]
---

# ⌘ FLEET COMMAND

<div class="statbar">
<span class="chip">refresh ✅ 4/4</span>
<span class="chip">repos <b>3</b></span>
<span class="chip ok">🟢 1</span>
<span class="chip warn">🟡 1</span>
<span class="chip bad">🔴 1 · crits <b>3</b></span>
<span class="chip dim">2026-08-20 07:04</span>
</div>

<div class="btnrow">
<a class="btn" href="obsidian://search?query=tag%3A%23health%2Fred">🔴 Reds</a>
<a class="btn" href="obsidian://search?query=tag%3A%23vuln%2Fcritical">⚠️ Criticals</a>
<a class="btn" href="obsidian://search?query=tag%3A%23campaign%2Fconnector-upgrade">🎯 Campaign</a>
<a class="btn" href="obsidian://search?query=path%3Anotes%2Finbox">📥 Inbox</a>
<a class="btn" href="curation.base">✏️ Curate</a>
<a class="btn act" href="file://./refresh.command">⟳ Refresh</a>
<a class="btn ext" href="https://jenkins.example.internal">Jenkins ▶</a>
<a class="btn ext" href="https://github.example.internal">GitHub ▶</a>
</div>

<div class="hero">
<img src="assets/health-donut.svg" width="200"/>
<img src="assets/crit-trend.svg" width="320"/>
<img src="assets/campaigns.svg" width="320"/>
</div>

## Board

![[fleet.base]]

> [!failure] 🚨 Needs attention
> - 🔴 [fraud-scorer](nodes/repos/repo.fraud-scorer.md) — 3 criticals · connector below target
> - ⚠️ [feature-builder-kfp](nodes/repos/repo.feature-builder-kfp.md) — stale signal since 08-12

> [!info] 🎯 Campaigns
> **connector-upgrade** — **1/2** · latest: txn-stream-rts ✅ 08-18
> [board →](meta/campaigns/campaign.connector-upgrade.md)

> [!tip] 🗓 Changed yesterday
> - [fraud-scorer](nodes/repos/repo.fraud-scorer.md) · 🟡→🔴 (vulns 1→3)
> - [txn-stream-rts](nodes/repos/repo.txn-stream-rts.md) · batch→realtime (override)
> [full diff →](indexes/daily/2026-08-20.md)

> [!todo] 🗂 My desk
> - 📥 **1** in [inbox](notes/inbox/capture-2026-08-19.md)
> - ☐ rotate creds — [fraud-scorer](nodes/repos/repo.fraud-scorer.md)
> - ✏️ 1 repo [needs curation](meta/repo.feature-builder-kfp.md)

<div class="btnrow footer">
<a class="btn" href="hubs/team.fraud-core.md">Teams</a>
<a class="btn" href="hubs/cat.batch.md">Categories</a>
<a class="btn" href="nodes/packages/pkg.snowflake-connector-python.md">Packages</a>
<a class="btn" href="views/Snowflake Readers.md">Views</a>
<a class="btn" href="Demo.md">🎬 Demo</a>
<a class="btn" href="docs/CONTRACT.md">Contract</a>
</div>
