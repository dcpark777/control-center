---
id: repo.feature-builder-kfp
node_type: repo
title: feature-builder-kfp
aliases: [feature-builder-kfp]
as_of: 2026-08-20
tags: [type/repo, cat/kfp, team/ml-platform, health/yellow]
category: kfp
team: ml-platform
health: yellow
completeness: 0.6
vulns_critical: 0
python: "3.10"
pyspark: "3.5.0"
snowflake_auth: password
signals_stale: [base_image_age_days]
deps:
  kfp: "2.7.0"
  pyspark: "3.5.0"
jenkins: https://jenkins.example.internal/job/feature-builder-kfp
github: https://github.example.internal/fraud/feature-builder-kfp
---

# 🟡 feature-builder-kfp

**KFP feature pipeline** · team **ml-platform**
[GitHub](https://github.example.internal/fraud/feature-builder-kfp) · [Jenkins ▶](https://jenkins.example.internal/job/feature-builder-kfp) · [cat.kfp](../../hubs/cat.kfp.md) · [team.ml-platform](../../hubs/team.ml-platform.md)

> [!warning] Why yellow
> - ⚠️ stale signal: `base_image_age_days` last collected 08-12
> - completeness **0.6** — missing: purpose → [add meta](../../meta/repo.feature-builder-kfp.md)

## Signals

| signal | value | as of | source |
|---|---:|---|---|
| vulns_critical | 0 | 08-20 | mend |
| base_image_age_days | 340 | ⚠️ 08-12 | dockerscan |

## Data flow

**Writes** → [txn_features](../tables/table.fraud-db.txn-features.md) · declared, verified

## History

- `08-15` pyspark 3.4.1→3.5.0

> [!quote]- Label provenance
> `category: kfp` — classified · rule `kfp-1` (file_glob `pipeline*.py` → `pipeline_v2.py`) · evaluated_sha `9f8e7d6`
