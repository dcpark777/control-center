# START_HERE_OPERATOR — Session 0, copy-paste edition

Audience: Command (the human). START_HERE.md is for Claude; RUNBOOK.md is
the full session-by-session path; this file is the literal keystrokes for
arrival. Assumes the zip landed in `~/Downloads` via your approved channel.

## 1. Unzip and baseline

```bash
cd ~ && unzip ~/Downloads/mission-project.zip -d ~/
cd ~/mission-project
git init && git add -A && git commit -m "baseline: design artifacts v0"
```

## 2. Alias + sanity check

```bash
echo 'alias mission="python3 ~/mission-project/mission-runtime/cli/mission.py"' >> ~/.zshrc
source ~/.zshrc
mission help                                # expect: the grouped menu
python3 -m pytest mission-runtime/cli -q    # expect: 15 passed
```

## 3. Health check, then launch Claude Code

```bash
cd ~/mission-project && claude
```

Inside the session, run `/doctor`. Skim the output — anything flagged goes
into `docs/environment.md` in the next step. Resolve settings-validity
complaints before installing the skill (Session 4).

## 4. Claude's first prompt (paste exactly)

> Read START_HERE.md and RUNBOOK.md in full. Adopt the standing build-log
> instruction from RUNBOOK.md: maintain docs/BUILDLOG.md, append-only,
> using the template at the bottom of the runbook. Then do Phase 0: run
> the remaining probes (most are pre-answered in the docs — verify, don't
> re-derive), include anything /doctor flagged, write docs/environment.md,
> and commit per START_HERE. Report back as a probe/result/implication
> table before writing any code.

## 5. After it reports — the two steps only you can do

- Add the allow-list line it recommends to `.claude/settings.json`, then
  verify: have it run a `mission status` call — no approval prompt should
  appear.
- Seed standing knowledge: your MCP directives into `CLAUDE.md`
  (user or repo level), and your real invocations into
  `crew.toml [commands]`, e.g. `test = "pipenv run pytest"`.

## 6. Close Session 0 (acceptance)

- `docs/environment.md` exists
- `docs/BUILDLOG.md` has entry #1
- `git log` shows two commits past baseline

Next sitting opens with: **"Do Phase 1."** From here RUNBOOK.md drives and
you mostly greenlight.
